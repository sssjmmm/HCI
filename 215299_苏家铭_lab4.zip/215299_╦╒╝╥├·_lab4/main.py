import dash
from dash.dependencies import Input, Output
from dash import dcc
from dash import html
import plotly.graph_objs as go
import pandas as pd

app = dash.Dash()

# 文件读取和清洗
df = pd.read_csv('dataset/google-play-store-apps/googleplaystore.csv', encoding='MacRoman')
df = df.dropna(axis=0, how="any")  # delete null values

# 获取每个目录的名字
names = df['Category'].unique()

# 计算每个category下app的下载次数
reviews = []
for name in names:
    all_num = 0
    dff = df[df['Category'] == name]['Reviews']
    # acquire data
    for d in dff:
        d = int(d)
        all_num += d
    reviews.append(all_num)

# 绘制饼状图
install_pie = go.Figure(data=go.Pie(
    labels=names,
    values=reviews,
    hoverinfo='label+value+percent',
    textinfo='none',
    rotation=220,
    customdata=names
),
    layout=go.Layout(
        title='Reviews for each category'
    )
)


months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
nums = []
for i in range(12):
    nums.append(0)
dic = dict(zip(months, nums))
ups = df['Last Updated']
for up in ups:
    _up = up.split('-')[1]
    index = months.index(_up)
    nums[index] = nums[index]+1

update_fig = go.Figure()
update_fig.add_trace(
    go.Scatter(
        x=months,
        y=nums
    )
)
update_fig.update_layout(
    title="Count of Apps Updated in Different Months",
    xaxis=dict(title="month"),
    yaxis=dict(title="count"),
    width=1200,
    height=500
)

# html
app.layout = html.Div([
    # dcc.RadioItems 这是一个单选项组件，用于选择不同的选项。在这里，它用于选择线性或对数类型。
    # id='type'：指定选项组件的唯一标识符，以便在后续的回调函数中引用该组件。
    # options=[{'label': type, 'value': type} for type in ['Linear', 'Log']]：
    # 设置选项组件的选项列表。在这里，它包括了"Linear"和"Log"两个选项。
    # value='Log'：设置选项组件的默认值为"Log"。
    # labelStyle={'display': 'inline-block', 'margin-left': '80%'}：设置选项组件的标签样式。
    # 这里设置标签在选项旁边显示，并且左边距为80%。
    # style：设置整个div元素的样式。
    # 'borderBottom': 'thin lightgrey solid'：设置底部边框为细线、浅灰色。
    # 'backgroundColor': '#6495ED'：设置背景颜色为RGB颜色码 #6495ED，即蓝色。
    # 'color': 'white'：设置文本颜色为白色。
    # 'padding': '10px 5px'：设置内边距为10像素顶部和底部，5像素左右。
    html.Div([
        html.Div([
            # 设置按钮
            dcc.RadioItems(
                id='type',
                options=[{'label': type, 'value': type} for type in ['Linear', 'Log']],
                value='Log',
                labelStyle={'display': 'inline-block', 'margin-left': '80%'}
            )
        ], style={'width': '45%', 'display': 'inline-block', 'margin-left': '45%'}
        )
    ], style={
            'borderBottom': 'thin lightgrey solid',
            'backgroundColor': '#6495ED',
            'color': 'white',
            'padding': '10px 5px'
        }
    ),
    # 设置饼状图
    html.Div(
        dcc.Graph(
            id='circle_graph',
            figure=install_pie,
            hoverData={'points': [{'customdata': 'ART_AND_DESIGN'}]}
        ), style={'display': 'inline-block', 'width': '49%'}
    ),
    # 设置点状图
    html.Div(
        [
            dcc.Graph(id='g1'),
            dcc.Graph(id='g2')
        ], style={'display': 'inline-block', 'width': '49%'}
    ),
    # 设置折线图
    html.Div(
        dcc.Graph(
            id='trace',
            figure=update_fig,
        ), style={'width': '100%', 'display': 'inline-block', 'padding': '0 20'}
    ),

])


# @app.callback：这是Dash库中用于定义回调函数的装饰器。
# Output('g1', 'figure')：指定回调函数的输出，即将更新的组件。
# 这里指定的是名为 'g1' 的图表组件的 figure 属性。
# [Input('type', 'value'), Input('circle_graph', 'hoverData')]：指定回调函数的输入，
# 即触发回调函数的事件或交互。这里指定了两个输入：
# Input('type', 'value')：指定了一个名为 'type' 的组件，
# 当其值（value）发生变化时触发回调函数。
# Input('circle_graph', 'hoverData')：指定了一个名为 'circle_graph' 的组件，
# 当鼠标悬停数据（hoverData）发生变化时触发回调函数
@app.callback(
    Output('g1', 'figure'),
    [
        Input('type', 'value'),
        Input('circle_graph', 'hoverData')
    ])
# 用于根据输入的类型和鼠标悬停数据来更新图表 'graph1' 的内容。
def update_g1(type, hover_data):
    # 首先，根据鼠标悬停数据中的 'customdata' 获取图表应该显示的特定分类的数据。
    # 在这里，dff 是一个新的 DataFrame，它包含与悬停数据中的 'customdata' 相匹配的分类。
    dff = df[df['Category'] == hover_data['points'][0]['customdata']]
    yData = []
    size = []
    s = dff['Size']
    ydata = dff['Installs']
    for yd in ydata:
        yd = yd[0:-1]  # 去除安装量数据中的最后一个字符
        print(yd)
        yd = yd.replace(',', '')  # 去除安装量数据中的逗号
        yd = int(yd)  # 将安装量数据转换为整数类型
        yData.append(yd)
    for _s in s:
        if _s == 'Varies with device':  # 如果应用程序大小为 'Varies with device'，将其大小设置为 0。
            size.append(0)
            continue
        if 'M' in _s:  # 如果应用程序大小包含 'M'，将其以 'M' 分割并取第一部分，然后将其转换为浮点数类型。
            _s = _s.split('M')[0]
            _s = float(_s)
        elif 'k' in _s:  # 如果应用程序大小包含 'k'，将其以 'k' 分割并取第一部分，然后将其转换为浮点数类型，并除以 1024，以将其转换为以 MB 为单位的大小。
            _s = _s.split('k')[0]
            _s = float(_s) / 1024
        size.append(_s / 2)  # 将处理后的应用程序大小数据添加到 size 列表中，同时将其除以 2 以调整大小。
    # 返回一个字典，其中包含更新后的图表的数据和布局。
    # 在 'data' 键中，指定了一个散点图（Scatter）对象，用于显示根据安装量和评分绘制的散点图。
    # 在 'layout' 键中，定义了图表的布局设置，如边距、高度、标题、坐标轴等。
    return {
        'data': [go.Scatter(
            x=dff['Rating'].astype(float),
            y=yData,
            mode='markers',
            text=dff['App'] + '<br> Last updated: ' + dff['Last Updated'] + '<br>Size: ' + dff['Size'],
            customdata=dff['App'],
            marker={
                'size': size,
                'opacity': 0.5,
                'color': '#8B7500',
                'line': {'width': 0.5, 'color': 'white'}
            }
        )],
        'layout': {
            'margin': {'l': 50, 'b': 30, 'r': 10, 't': 10},
            'height': 225,
            'annotations': [{
                'x': 0, 'y': 0.85, 'xanchor': 'left', 'yanchor': 'bottom',
                'xref': 'paper', 'yref': 'paper', 'showarrow': False,
                'align': 'left', 'bgcolor': 'rgba(255, 255, 255, 0.5)',
                'text': hover_data['points'][0]['customdata']
            }],
            'yaxis': {
                'title': 'Installs',
                'type': 'linear' if type == 'Linear' else 'log'
            },
            'xaxis': {
                'title': 'Rating',
                'showgrid': True
            },
            'hovermode': 'closest'
        }
    }


# 对g2做类似操作
@app.callback(Output('g2', 'figure'),
              [Input('circle_graph', 'hoverData'),
               Input('type', 'value')])
def update_g2(hover_data, type):
    dff = df[hover_data['points'][0]['customdata'] == df['Category']]
    return {
        'data': [go.Scatter(
            x=dff['Rating'].astype(float),
            y=dff['Reviews'].astype(int),
            mode='markers',
            text=dff['App'] + '<br> Last updated: ' + dff['Last Updated'] + '<br>Size: ' + dff['Size'],
            customdata=dff['App'],
            marker={
                'size': 10,
                'opacity': 0.5,
                'color': '#00868B',
                'line': {'width': 0.5, 'color': 'white'}
            }
        )],
        'layout': {
            'margin': {'l': 50, 'b': 30, 'r': 10, 't': 10},
            'height': 225,
            'annotations': [{
                'x': 0, 'y': 0.85, 'xanchor': 'left', 'yanchor': 'bottom',
                'xref': 'paper', 'yref': 'paper', 'showarrow': False,
                'align': 'left', 'bgcolor': 'rgba(255, 255, 255, 0.5)',
                'text': hover_data['points'][0]['customdata']
            }],
            'yaxis': {
                'title': 'Reviews',
                'type': 'linear' if type == 'Linear' else 'log'
            },
            'xaxis': {
                'title': 'Rating',
                'showgrid': True
            },
            'hovermode': 'closest'
        }
    }


if __name__ == '__main__':
    app.run_server(debug=True)