// 展示预览图片
function showImg(input) {
  var file = input.files[0];
  var reader = new FileReader()
  reader.readAsDataURL(file)
  // load 事件的处理函数
  reader.onload = function (reader) {
    document.getElementById("previmg").src = reader.target.result;
    document.getElementById("previmg").style.display = "block";
  }
}

// 定义集合存放收藏的图片
var favoriteSet = new Set();

// 单击收藏图标后，改变图标并加入收藏列表
function changeFavIcon(x, num) {
  x.classList.toggle("fa-heartbeat");
  // 如果有收藏
  if (x.classList.contains("fa-heartbeat")) {
    var dis = document.getElementById("img" + num).src;
    favoriteSet.add(dis);
  }
  else {// 没有收藏
    var dis = document.getElementById("img" + num).src;
    favoriteSet.delete(dis);
  }
}

// 展示收藏图片
function showFavPic() {
  document.getElementById('favor-modal').style.display = 'block'
  // 将favoriteSet对象转换为数组fav_list
  var fav_list = [...favoriteSet]
  console.log(fav_list)
  var element = document.getElementById("img_fav_list");
  element.innerHTML = ""
  for (let i = 0; i < fav_list.length; i++) {
    var fav_img = document.createElement("img");
    fav_img.src = fav_list[i];
    fav_img.style = "width:200px;height:200px;padding:2%";
    element.appendChild(fav_img)
  }
}

// 核心函数，展示搜索结果图片
function fun() {
  $("form").submit(function (evt) {
    // 先显示“加载动画”
    document.getElementById("load").style.display = "block";
    evt.preventDefault();
    // 使用FormData对象来存储表单数据
    var formData = new FormData($(this)[0]);
    // 使用jQuery的$.ajax()方法发送异步POST请求
    $.ajax({
      url: 'imgUpload',
      type: 'POST',
      data: formData,
      //async: false,
      cache: false,
      contentType: false,
      enctype: 'multipart/form-data',
      processData: false,

      // 成功响应时，函数将接收到的数据更新页面上的图片和标签
      success: function (response) {

        console.log(response);
        document.getElementById("load").style.display = "none";
        document.getElementById("search-results").style.display = "block";
        // 更新九张图片的图片地址和标签信息
        document.getElementById("img0").src = response.image0[0];
        document.getElementById("tag0").innerHTML = response.image0[1];
        document.getElementById("img1").src = response.image1[0];
        document.getElementById("tag1").innerHTML = response.image1[1];
        document.getElementById("img2").src = response.image2[0];
        document.getElementById("tag2").innerHTML = response.image2[1];
        document.getElementById("img3").src = response.image3[0];
        document.getElementById("tag3").innerHTML = response.image3[1];
        document.getElementById("img4").src = response.image4[0];
        document.getElementById("tag4").innerHTML = response.image4[1];
        document.getElementById("img5").src = response.image5[0]
        document.getElementById("tag5").innerHTML = response.image5[1];
        document.getElementById("img6").src = response.image6[0]
        document.getElementById("tag6").innerHTML = response.image6[1];
        document.getElementById("img7").src = response.image7[0]
        document.getElementById("tag7").innerHTML = response.image7[1];
        document.getElementById("img8").src = response.image8[0]
        document.getElementById("tag8").innerHTML = response.image8[1];


        // 更新Filter下拉菜单中的标签信息
        var tagSets = new Set();
        // 定义tagSets集合，存放每个图片的标签内容，这个set包含了所有不同的标签元素
        // 注意: 每个标签元素只出现一次，因为Set对象不允许重复元素，用于refinement再通过标签筛选图片
        for (let i = 0; i < 9; i++) {
          tagSets.add(document.getElementById("tag" + i).innerHTML);
        }
        console.log(tagSets);
        // 将tagSets对象转换为数组tag_list
        var tag_list = [...tagSets]
        var tag_name_list = ["fig0", "fig1", "fig2", "fig3", "fig4", "fig5", "fig6", "fig7", "fig8"];
        document.getElementById("figAll").textContent = "all";
        document.getElementById("figAll").style.display = "block";
        // 循环遍历，将所有标签元素的内容传到Filter筛选下拉框中
        for (var i = 0; i < tag_list.length; i++) {
          document.getElementById(tag_name_list[i]).textContent = tag_list[i]
          document.getElementById(tag_name_list[i]).style.display = "block";
        }


        // 收藏图标的显示
        if (favoriteSet.size != 0) {
          for (let i = 0; i < 9; i++) {
            // 首先将所有图标恢复默认的黑色爱心状态
            document.getElementById("icon" + i).classList.remove("fa-heartbeat");
            // ————若该图片曾经已收藏过，则需更新图标为标红爱心
            if (favoriteSet.has(document.getElementById("img" + i).src))
              document.getElementById("icon" + i).classList.toggle("fa-heartbeat");
            // ————若该图片未收藏过，则仍然是默认的黑色爱心
          }
        }

      }
    });
    return false;
  })
};

// 清除屏幕，重新开始图片检索
function reset() {
  document.getElementById("previmg").style.display = "none";
  document.getElementById("search-results").style.display = "none";
}

// 筛选按钮被单击时，下拉框进行展开或收起
function dropFunction() {
  var x = document.getElementById("myDIV");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// 该函数实现单击标签后进行筛选的功能
function filter(num) {

  // 首先设置初始状态：所有（9张）卡片全部显示
  for (let i = 0; i < 9; i++) {
    document.getElementById("img" + i).style.opacity = "1";
    document.getElementById("t" + i).style.display = "block";
    document.getElementById("icon" + i).style.display = "block";
  }

  // 如果单击不是all，则只显示对应标签的卡片，其他设为透明
  if (num != -1) {
    // 先获取被选中标签的内容
    var tagContent = document.getElementById("fig" + num).innerHTML;
    for (let i = 0; i < 9; i++) {
      // 不是所选标签内容的卡片设为透明
      if (document.getElementById("tag" + i).innerHTML != tagContent) {
        document.getElementById("img" + i).style.opacity = "0.1";
        document.getElementById("t" + i).style.display = "none";
        document.getElementById("icon" + i).style.display = "none";
      }
    }
  }
}
